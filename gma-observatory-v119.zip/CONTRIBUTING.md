# Contribution au protocole Delphi — Observatoire GMA

## Appel à experts volontaires — Calibration n = 20

L'Observatoire International GMA recherche des experts volontaires pour participer au **protocole Delphi de calibration** du système d'alerte mésologique globale.

---

## Qui recherchons-nous ?

Des experts dans les domaines suivants :

- Écologie et biologie de la conservation
- Hydrogéologie et gestion des ressources en eau
- Gouvernance territoriale et institutions
- Modélisation socio-écologique
- Géographie physique et humaine
- Anthropologie écologique et savoirs locaux
- Télédétection et SIG
- Science des données environnementales

---

## Objectifs du protocole Delphi

1. **Calibrer les poids μᵢ** des vulnérabilités dans le calcul du BRₘ
2. **Valider les sites candidats** (n = 15 sites internationaux)
3. **Affiner les ancres de normalisation** par biome (9 biomes de référence)
4. **Tester la robustesse** du seuil heuristique provisoire (≈ 1,20)

---

## Modalités

- **Format** : protocole Delphi en 3 rounds (novembre–décembre 2026)
- **Méthode** : double notation en aveugle, poids fixés avant courbe ROC
- **Taille cible** : n = 20 experts
- **Durée estimée** : 2–3 heures par round
- **Langue** : français ou anglais
- **Compensation** : participation bénévole, co-auteur selon contribution

---

## Prérequis

Avant de participer, il est recommandé de consulter :

1. L'ouvrage de référence : DOI [10.5281/zenodo.22738126](https://doi.org/10.5281/zenodo.22738126)
2. Le document Biome Baselines : DOI [10.5281/zenodo.22738208](https://doi.org/10.5281/zenodo.22738208)
3. Le concept initial : DOI [10.5281/zenodo.22391967](https://doi.org/10.5281/zenodo.22391967)

---

## Comment candidater

### Option 1 : via le site web
Rendez-vous sur la section **Delphi** du site et remplissez le formulaire structuré.

### Option 2 : par email
Envoyez un email à **forestecolo@gmail.com** avec :

- Nom complet
- Affiliation institutionnelle
- Domaine d'expertise
- Proposition de site à valider (optionnel)
- Commentaire ou question (optionnel)

### Option 3 : via GitHub
Ouvrez une issue sur ce dépôt avec le label `delphi-candidate`.

---

## Critères de sélection

- Expertise démontrée dans un domaine pertinent
- Disponibilité pour les 3 rounds du protocole
- Capacité à évaluer des sites dans au moins un biome de référence
- Engagement à respecter les règles de double notation en aveugle

---

## Engagement de l'Observatoire

- Transparence sur les méthodes et les données
- Reconnaissance des contributeurs (co-auteur selon contribution)
- Mise à disposition des résultats sous licence ouverte
- Aucune utilisation commerciale sans accord préalable

---

## Contact

- **Email** : forestecolo@gmail.com
- **ORCID** : [0000-0002-5577-9336](https://orcid.org/0000-0002-5577-9336)
- **Site** : [cerclevertdz-ai.github.io/gma-observatory](https://cerclevertdz-ai.github.io/gma-observatory/)

---

*Observatoire International GMA — Capital Vivant*  
*Mourad Ahmim, 2026*
